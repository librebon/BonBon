// Copyright (c) the JPEG XL Project Authors.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

#ifndef JPEGLI_LIB_EXTRAS_SIZE_CONSTRAINTS_H_
#define JPEGLI_LIB_EXTRAS_SIZE_CONSTRAINTS_H_

#include <cstdint>
#include <type_traits>

#include "lib/base/status.h"

namespace jpegli {

struct SizeConstraints {
  // Upper limit on pixel dimensions/area, enforced by VerifyDimensions
  // (called from decoders). Fuzzers set smaller values to limit memory use.
  // Default values correspond to JXL level 10.
  uint32_t dec_max_xsize = 1u << 30;
  uint32_t dec_max_ysize = 1u << 30;
  uint64_t dec_max_pixels = static_cast<uint64_t>(1u) << 40;
};

template <typename T,
          class = typename std::enable_if<std::is_unsigned<T>::value>::type>
Status VerifyDimensions(const SizeConstraints* constraints, T xs, T ys) {
  SizeConstraints limit = {};
  if (constraints) limit = *constraints;

  if (xs == 0 || ys == 0) return JPEGLI_FAILURE("Empty image.");
  if (xs > limit.dec_max_xsize) return JPEGLI_FAILURE("Image too wide.");
  if (ys > limit.dec_max_ysize) return JPEGLI_FAILURE("Image too tall.");

  const uint64_t num_pixels = static_cast<uint64_t>(xs) * ys;
  if (num_pixels > limit.dec_max_pixels) {
    return JPEGLI_FAILURE("Image too big.");
  }

  return true;
}

}  // namespace jpegli

#endif  // JPEGLI_LIB_EXTRAS_SIZE_CONSTRAINTS_H_
