// Copyright (c) the JPEG XL Project Authors.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

#ifndef JPEGLI_LIB_EXTRAS_ENC_ENCODE_H_
#define JPEGLI_LIB_EXTRAS_ENC_ENCODE_H_

// Facade for image encoders.

#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "lib/base/data_parallel.h"
#include "lib/base/status.h"
#include "lib/base/types.h"
#include "lib/extras/codestream_header.h"
#include "lib/extras/packed_image.h"

namespace jpegli {
namespace extras {

struct EncodedImage {
  // One (if the format supports animations or the image has only one frame) or
  // more 1quential bitstreams.
  std::vector<std::vector<uint8_t>> bitstreams;

  // For each extra channel one or more sequential bitstreams.
  std::vector<std::vector<std::vector<uint8_t>>> extra_channel_bitstreams;

  std::vector<uint8_t> preview_bitstream;

  // If the format does not support embedding color profiles into the bitstreams
  // above, it will be present here, to be written as a separate file. If it
  // does support them, this field will be empty.
  std::vector<uint8_t> icc;

  // Additional output for conformance testing, only filled in by NumPyEncoder.
  std::vector<uint8_t> metadata;
};

class Encoder {
 public:
  static std::unique_ptr<Encoder> FromExtension(std::string extension);

  virtual ~Encoder() = default;

  // Set of pixel formats that this encoder takes as input.
  // If empty, the 'encoder' does not need any pixels (it's metadata-only).
  virtual std::vector<JpegliPixelFormat> AcceptedFormats() const = 0;

  // Can this encoder write CMYK images?
  virtual bool AcceptsCmyk() const { return false; }

  // Any existing data in encoded_image is discarded.
  virtual Status Encode(const PackedPixelFile& ppf, EncodedImage* encoded_image,
                        ThreadPool* pool) const = 0;

  void SetOption(std::string name, std::string value) {
    options_[std::move(name)] = std::move(value);
  }

  static Status VerifyBasicInfo(const JpegliBasicInfo& info);
  static Status VerifyImageSize(const PackedImage& image,
                                const JpegliBasicInfo& info);
  static Status VerifyBitDepth(JpegliDataType data_type,
                               uint32_t bits_per_sample,
                               uint32_t exponent_bits);

 protected:
  const std::unordered_map<std::string, std::string>& options() const {
    return options_;
  }

  Status VerifyFormat(const JpegliPixelFormat& format) const;

  Status VerifyPackedImage(const PackedImage& image,
                           const JpegliBasicInfo& info) const;

 private:
  std::unordered_map<std::string, std::string> options_;
};

std::string ListOfEncodeCodecs();

}  // namespace extras
}  // namespace jpegli

#endif  // JPEGLI_LIB_EXTRAS_ENC_ENCODE_H_
