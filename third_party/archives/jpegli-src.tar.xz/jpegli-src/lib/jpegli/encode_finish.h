// Copyright (c) the JPEG XL Project Authors.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

#ifndef JPEGLI_LIB_JPEGLI_ENCODE_FINISH_H_
#define JPEGLI_LIB_JPEGLI_ENCODE_FINISH_H_

#include "lib/jpegli/common.h"

namespace jpegli {

void QuantizetoPSNR(j_compress_ptr cinfo);

}  // namespace jpegli

#endif  // JPEGLI_LIB_JPEGLI_ENCODE_FINISH_H_
