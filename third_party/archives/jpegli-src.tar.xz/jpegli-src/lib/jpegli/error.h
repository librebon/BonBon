// Copyright (c) the JPEG XL Project Authors.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

#ifndef JPEGLI_LIB_JPEGLI_ERROR_H_
#define JPEGLI_LIB_JPEGLI_ERROR_H_

#include <stdarg.h>
#include <stdint.h>

#include "lib/base/compiler_specific.h"
#include "lib/jpegli/common.h"

namespace jpegli {

bool FormatString(char* buffer, const char* format, ...);

}  // namespace jpegli

// `error_exit` should be no-return; but let's add some guarantees on our side.
#define JPEGLI_ERROR(format, ...)                                            \
  jpegli::FormatString(cinfo->err->msg_parm.s, ("%s:%d: " format), __FILE__, \
                       __LINE__, ##__VA_ARGS__),                             \
      (*cinfo->err->error_exit)(reinterpret_cast<j_common_ptr>(cinfo)),      \
      JPEGLI_CRASH()

#define JPEGLI_WARN(format, ...)                                             \
  jpegli::FormatString(cinfo->err->msg_parm.s, ("%s:%d: " format), __FILE__, \
                       __LINE__, ##__VA_ARGS__),                             \
      (*cinfo->err->emit_message)(reinterpret_cast<j_common_ptr>(cinfo), -1)

#define JPEGLI_TRACE(level, format, ...)                                     \
  if (cinfo->err->trace_level >= (level))                                    \
  jpegli::FormatString(cinfo->err->msg_parm.s, ("%s:%d: " format), __FILE__, \
                       __LINE__, ##__VA_ARGS__),                             \
      (*cinfo->err->emit_message)(reinterpret_cast<j_common_ptr>(cinfo),     \
                                  (level))

#define JPEGLI_CHECK(condition)                     \
  do {                                              \
    if (!(condition)) {                             \
      JPEGLI_ERROR("JPEGLI_CHECK: %s", #condition); \
    }                                               \
  } while (0)

#endif  // JPEGLI_LIB_JPEGLI_ERROR_H_
